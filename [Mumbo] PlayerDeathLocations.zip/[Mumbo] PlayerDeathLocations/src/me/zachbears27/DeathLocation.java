package me.zachbears27;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import me.zachbears27.MySQL;

public class DeathLocation extends JavaPlugin implements Listener {
	DeathLocation plugin;

	MySQL MySQLC = new MySQL("localhost", "3306", "id115504_mumbo", "PandaDBUser", "PandaDBUserpw");
	   Connection c = null;


 @Override
 public void onDisable() {

 }

 @Override
 public void onEnable() {

  getServer().getPluginManager().registerEvents(this, this);
  try {
	c = MySQLC.openConnection();
	Bukkit.broadcastMessage("uau");
} catch (ClassNotFoundException e) {
	e.printStackTrace();
} catch (SQLException e) {

	e.printStackTrace();
}

}
 

/* @EventHandler
 public void onPlayerDeath(PlayerDeathEvent e) {
  if (e.getEntity() instanceof Player) {
   Player p = e.getEntity();
   Location loc = e.getEntity().getLocation();
   int x = loc.getBlockX();
   int y = loc.getBlockY();
   int z = loc.getBlockZ();
   String time = "its time";
   Bukkit.broadcastMessage(x + " " + y + " " + z ); 
   String statementstring = "INSERT INTO `" + "id115504_mumbo" + "`DeathLocations` (`PlayerName`, `X`, `Y`, `Z`, `Time`) VALUES (`" + p.getName() + "`, '" + x + "', '" + y + "', '" + z + "', '" + time + "');";
   Bukkit.broadcastMessage(statementstring);
   try {
	Statement statement = c.createStatement();
	statement.executeUpdate(statementstring);
} catch (SQLException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
 }
 }
 
*/
}